import Link from "next/link";
import { FileSearch, Search } from "lucide-react";
import { Badge, PageHeader } from "@/components/ui";
import { builders, documents, documentTypes, getBuilder, getProject, projects } from "@/lib/mock-data";
import { formatFileSize } from "@/lib/utils";

export default function SearchDocumentsPage() {
  return (
    <>
      <PageHeader
        title="Search documents"
        description="Filter by builder, project, city, document type, tags, and description."
      />
      <section className="panel mb-6 p-5">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input className="field pl-9" placeholder="Search: Jasmine RERA, Lavender tower info, payment plan..." />
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-4">
          <select className="field">
            <option>All builders</option>
            {builders.map((builder) => (
              <option key={builder.id}>{builder.name}</option>
            ))}
          </select>
          <select className="field">
            <option>All projects</option>
            {projects.map((project) => (
              <option key={project.id}>{project.name}</option>
            ))}
          </select>
          <select className="field">
            <option>All cities</option>
            {[...new Set(projects.map((project) => project.city))].map((city) => (
              <option key={city}>{city}</option>
            ))}
          </select>
          <select className="field">
            <option>All document types</option>
            {documentTypes.map((type) => (
              <option key={type}>{type}</option>
            ))}
          </select>
        </div>
      </section>

      <section className="grid gap-4">
        {documents.map((document) => {
          const builder = getBuilder(document.builderId);
          const project = getProject(document.projectId);
          return (
            <article key={document.id} className="panel p-5">
              <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                <div className="flex gap-4">
                  <div className="hidden h-12 w-12 items-center justify-center rounded-md bg-primary/10 text-primary sm:flex">
                    <FileSearch className="h-6 w-6" />
                  </div>
                  <div>
                    <h2 className="font-semibold">{document.title}</h2>
                    <p className="mt-1 text-sm text-muted-foreground">{document.description}</p>
                    <p className="mt-2 text-xs text-muted-foreground">
                      {builder?.name} ·{" "}
                      <Link href={`/projects/${project?.id}`} className="font-semibold text-primary">
                        {project?.name}
                      </Link>{" "}
                      · {project?.city}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Badge className="bg-primary/10 text-primary">{document.type}</Badge>
                      {document.tags.map((tag) => (
                        <Badge key={tag}>{tag}</Badge>
                      ))}
                      {document.relatedTower ? <Badge>{document.relatedTower}</Badge> : null}
                    </div>
                  </div>
                </div>
                <div className="text-sm text-muted-foreground md:text-right">
                  <p>{document.fileName}</p>
                  <p>{formatFileSize(document.sizeMb)}</p>
                  <p>{document.uploadDate}</p>
                </div>
              </div>
            </article>
          );
        })}
      </section>
    </>
  );
}
