import type { Builder, DocumentType, Project, ProjectDocument } from "@/lib/types";

export const documentTypes: DocumentType[] = [
  "Project information",
  "Tower information",
  "Floor plan",
  "Unit details",
  "Amenities",
  "Pricing",
  "Legal document",
  "RERA certificate",
  "Possession details",
  "Payment plan",
  "Brochure",
  "Other",
];

export const builders: Builder[] = [
  {
    id: "bld-1",
    name: "Urban Nest Developers",
    address: "12 Business Park Road, Sector 62",
    contactPerson: "Anika Mehra",
    phone: "+91 98765 43210",
    email: "anika@urbannest.example",
  },
  {
    id: "bld-2",
    name: "Skyline Habitat Group",
    address: "4th Floor, Meridian Plaza, MG Road",
    contactPerson: "Rohit Sharma",
    phone: "+91 99887 77665",
    email: "sales@skylinehabitat.example",
  },
  {
    id: "bld-3",
    name: "GreenArc Realty",
    address: "Plot 41, Tech Corridor, Whitefield",
    contactPerson: "Neha Iyer",
    phone: "+91 91234 56780",
    email: "docs@greenarc.example",
  },
];

export const projects: Project[] = [
  {
    id: "prj-1",
    builderId: "bld-1",
    name: "Lavender Heights",
    address: "Golf Course Extension Road",
    city: "Gurugram",
    state: "Haryana",
    reraNumber: "HRERA-GGM-2026-142",
    status: "Under construction",
    towers: ["Tower A", "Tower B", "Tower C"],
  },
  {
    id: "prj-2",
    builderId: "bld-2",
    name: "Jasmine Residency",
    address: "Sarjapur Main Road",
    city: "Bengaluru",
    state: "Karnataka",
    reraNumber: "PRM/KA/RERA/1251/446",
    status: "Ready to move",
    towers: ["Jasmine East", "Jasmine West"],
  },
  {
    id: "prj-3",
    builderId: "bld-3",
    name: "Cedar Court",
    address: "Hinjewadi Phase 2",
    city: "Pune",
    state: "Maharashtra",
    reraNumber: "P52100048920",
    status: "Planning",
    towers: ["Block 1", "Block 2"],
  },
];

export const documents: ProjectDocument[] = [
  {
    id: "doc-1",
    builderId: "bld-1",
    projectId: "prj-1",
    title: "Lavender Heights master brochure",
    description: "Project overview, amenities, location highlights, and tower summary.",
    type: "Brochure",
    fileName: "Lavender.pdf",
    uploadDate: "2026-05-18",
    sizeMb: 8.4,
    tags: ["overview", "amenities", "location"],
    notes: "Good source for chatbot project summary answers.",
  },
  {
    id: "doc-2",
    builderId: "bld-1",
    projectId: "prj-1",
    title: "Tower A configuration sheet",
    description: "Tower-wise floors, lifts, unit mix, and possession milestone.",
    type: "Tower information",
    fileName: "lavender-tower-a.pdf",
    uploadDate: "2026-05-19",
    sizeMb: 3.2,
    tags: ["tower", "configuration", "possession"],
    notes: "Use tower field while indexing.",
    relatedTower: "Tower A",
  },
  {
    id: "doc-3",
    builderId: "bld-2",
    projectId: "prj-2",
    title: "Jasmine floor plans",
    description: "2 BHK and 3 BHK layout sheets with carpet area and balcony details.",
    type: "Floor plan",
    fileName: "Jasmine.pdf",
    uploadDate: "2026-05-17",
    sizeMb: 6.1,
    tags: ["2bhk", "3bhk", "floor plan"],
    notes: "Split by unit type in future OCR pipeline.",
    relatedTower: "Jasmine East",
    relatedUnitType: "2 BHK, 3 BHK",
  },
  {
    id: "doc-4",
    builderId: "bld-3",
    projectId: "prj-3",
    title: "Cedar Court payment plan",
    description: "Construction linked payment schedule and booking amount.",
    type: "Payment plan",
    fileName: "cedar-payment-plan.pdf",
    uploadDate: "2026-05-15",
    sizeMb: 1.8,
    tags: ["payment", "pricing", "booking"],
    notes: "Useful for commercial queries.",
  },
  {
    id: "doc-5",
    builderId: "bld-2",
    projectId: "prj-2",
    title: "RERA registration certificate",
    description: "Approved RERA details and registration validity.",
    type: "RERA certificate",
    fileName: "jasmine-rera.pdf",
    uploadDate: "2026-05-12",
    sizeMb: 2.4,
    tags: ["rera", "legal", "approval"],
    notes: "Keep as trusted document.",
  },
];

export function getBuilder(id: string) {
  return builders.find((builder) => builder.id === id);
}

export function getProject(id: string) {
  return projects.find((project) => project.id === id);
}

export function getDocumentsForProject(projectId: string) {
  return documents.filter((document) => document.projectId === projectId);
}
