import { PageHeader } from "@/components/ui";
import { builders, projects } from "@/lib/mock-data";

export function ProjectForm({ mode, projectId }: { mode: "add" | "edit"; projectId?: string }) {
  const project = projects.find((item) => item.id === projectId);

  return (
    <>
      <PageHeader
        title={mode === "add" ? "Add project" : "Edit project"}
        description="Store project details and RERA metadata so documents are easier to search later."
      />
      <form className="panel max-w-4xl space-y-5 p-5">
        {/* TODO: Replace mock submit with backend API persistence. */}
        <div className="grid gap-5 md:grid-cols-2">
          <label className="space-y-2">
            <span className="label">Project name</span>
            <input className="field" defaultValue={project?.name} placeholder="Lavender Heights" />
          </label>
          <label className="space-y-2">
            <span className="label">Builder</span>
            <select className="field" defaultValue={project?.builderId}>
              <option value="">Select builder</option>
              {builders.map((builder) => (
                <option key={builder.id} value={builder.id}>
                  {builder.name}
                </option>
              ))}
            </select>
          </label>
          <label className="space-y-2 md:col-span-2">
            <span className="label">Project location/address</span>
            <input className="field" defaultValue={project?.address} placeholder="Street, sector, landmark" />
          </label>
          <label className="space-y-2">
            <span className="label">City</span>
            <input className="field" defaultValue={project?.city} placeholder="Gurugram" />
          </label>
          <label className="space-y-2">
            <span className="label">State</span>
            <input className="field" defaultValue={project?.state} placeholder="Haryana" />
          </label>
          <label className="space-y-2">
            <span className="label">RERA number</span>
            <input className="field" defaultValue={project?.reraNumber} placeholder="HRERA-GGM-2026-142" />
          </label>
          <label className="space-y-2">
            <span className="label">Project status</span>
            <select className="field" defaultValue={project?.status ?? "Under construction"}>
              <option>Planning</option>
              <option>Under construction</option>
              <option>Ready to move</option>
              <option>Delivered</option>
            </select>
          </label>
        </div>
        <label className="space-y-2">
          <span className="label">Towers / blocks</span>
          <input className="field" defaultValue={project?.towers.join(", ")} placeholder="Tower A, Tower B, Block 1" />
        </label>
        <div className="flex justify-end gap-3">
          <button type="button" className="h-10 rounded-md border bg-white px-4 text-sm font-semibold">
            Cancel
          </button>
          <button type="submit" className="h-10 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground">
            Save project
          </button>
        </div>
      </form>
    </>
  );
}
