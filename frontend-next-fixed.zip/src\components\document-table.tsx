import { Download, Eye, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui";
import { documents, getBuilder, getProject } from "@/lib/mock-data";
import { formatFileSize } from "@/lib/utils";

export function DocumentTable() {
  return (
    <div className="panel overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[900px] text-sm">
          <thead className="bg-secondary text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-5 py-3">Document</th>
              <th className="px-5 py-3">Builder</th>
              <th className="px-5 py-3">Project</th>
              <th className="px-5 py-3">Type</th>
              <th className="px-5 py-3">Uploaded</th>
              <th className="px-5 py-3">Size</th>
              <th className="px-5 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {documents.map((document) => {
              const builder = getBuilder(document.builderId);
              const project = getProject(document.projectId);
              return (
                <tr key={document.id} className="bg-white align-top">
                  <td className="px-5 py-4">
                    <p className="font-medium">{document.title}</p>
                    <p className="text-xs text-muted-foreground">{document.fileName}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {document.tags.map((tag) => (
                        <Badge key={tag}>{tag}</Badge>
                      ))}
                    </div>
                  </td>
                  <td className="px-5 py-4">{builder?.name}</td>
                  <td className="px-5 py-4">{project?.name}</td>
                  <td className="px-5 py-4">
                    <Badge className="bg-primary/10 text-primary">{document.type}</Badge>
                  </td>
                  <td className="px-5 py-4">{document.uploadDate}</td>
                  <td className="px-5 py-4">{formatFileSize(document.sizeMb)}</td>
                  <td className="px-5 py-4">
                    <div className="flex justify-end gap-2">
                      {[Eye, Download, Trash2].map((Icon, index) => (
                        <button
                          key={index}
                          className="rounded-md border p-2 text-muted-foreground transition hover:bg-secondary hover:text-foreground"
                          aria-label="Document action"
                        >
                          <Icon className="h-4 w-4" />
                        </button>
                      ))}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
