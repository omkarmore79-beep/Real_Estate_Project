import Link from "next/link";
import { Edit, FileText, MapPin, Plus } from "lucide-react";
import { Badge, ButtonLink, PageHeader } from "@/components/ui";
import { documents, getBuilder, projects } from "@/lib/mock-data";

export default function ProjectsPage() {
  return (
    <>
      <PageHeader
        title="Projects"
        description="Project records connected with builders, RERA details, and uploaded documents."
        action={
          <ButtonLink href="/projects/new">
            <Plus className="h-4 w-4" />
            Add project
          </ButtonLink>
        }
      />
      <div className="grid gap-4 lg:grid-cols-2">
        {projects.map((project) => {
          const builder = getBuilder(project.builderId);
          const documentCount = documents.filter((document) => document.projectId === project.id).length;
          return (
            <article key={project.id} className="panel p-5">
              <div className="mb-4 flex items-start justify-between gap-4">
                <div>
                  <Link href={`/projects/${project.id}`} className="text-lg font-semibold hover:text-primary">
                    {project.name}
                  </Link>
                  <p className="mt-1 text-sm text-muted-foreground">{builder?.name}</p>
                </div>
                <ButtonLink href={`/projects/${project.id}/edit`} variant="secondary">
                  <Edit className="h-4 w-4" />
                </ButtonLink>
              </div>
              <div className="grid gap-3 text-sm sm:grid-cols-2">
                <p className="flex gap-2 text-muted-foreground">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
                  {project.address}, {project.city}
                </p>
                <p className="font-mono text-xs text-muted-foreground">RERA: {project.reraNumber}</p>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                <Badge>{project.status}</Badge>
                <Badge className="bg-primary/10 text-primary">
                  <FileText className="mr-1 h-3 w-3" />
                  {documentCount} documents
                </Badge>
                {project.towers.map((tower) => (
                  <Badge key={tower}>{tower}</Badge>
                ))}
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}
