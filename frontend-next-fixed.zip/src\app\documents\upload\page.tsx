import { FileUp, Info, Upload } from "lucide-react";
import { Badge, PageHeader } from "@/components/ui";
import { builders, documentTypes, projects } from "@/lib/mock-data";

export default function UploadDocumentPage() {
  return (
    <>
      <PageHeader
        title="Upload document"
        description="Add a file, classify what it contains, and enrich it with metadata for easier chatbot search."
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <form className="panel space-y-6 p-5">
          {/* TODO: Replace this mock upload form with real file storage and ingestion API calls. */}
          <div className="rounded-lg border border-dashed bg-secondary/60 p-8 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-md bg-white text-primary shadow-sm">
              <FileUp className="h-7 w-7" />
            </div>
            <p className="mt-4 font-semibold">Drop project documents here</p>
            <p className="mt-1 text-sm text-muted-foreground">PDF, DOCX, PNG, or JPG up to 50 MB</p>
            <button type="button" className="mt-4 h-10 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground">
              Browse files
            </button>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <label className="space-y-2">
              <span className="label">Builder name</span>
              <select className="field">
                <option value="">Select builder</option>
                {builders.map((builder) => (
                  <option key={builder.id}>{builder.name}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2">
              <span className="label">Project name</span>
              <select className="field">
                <option value="">Select project</option>
                {projects.map((project) => (
                  <option key={project.id}>{project.name}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2">
              <span className="label">Type of document</span>
              <select className="field">
                <option value="">What does this document contain?</option>
                {documentTypes.map((type) => (
                  <option key={type}>{type}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2">
              <span className="label">Document title</span>
              <input className="field" placeholder="Tower A configuration sheet" />
            </label>
            <label className="space-y-2 md:col-span-2">
              <span className="label">Short description</span>
              <textarea className="textarea-field" placeholder="Describe the important information this file contains." />
            </label>
            <label className="space-y-2">
              <span className="label">Tags / keywords</span>
              <input className="field" placeholder="pricing, 2bhk, possession, amenities" />
            </label>
            <label className="space-y-2">
              <span className="label">Related tower / block</span>
              <input className="field" placeholder="Tower A, Jasmine East, Block 1" />
            </label>
            <label className="space-y-2">
              <span className="label">Related unit type</span>
              <input className="field" placeholder="2 BHK, 3 BHK, Penthouse" />
            </label>
            <label className="space-y-2">
              <span className="label">Upload date</span>
              <input className="field" type="date" defaultValue="2026-05-21" />
            </label>
            <label className="space-y-2 md:col-span-2">
              <span className="label">Notes</span>
              <textarea className="textarea-field" placeholder="Any indexing hints or document quality notes." />
            </label>
          </div>

          <div className="flex justify-end gap-3">
            <button type="button" className="h-10 rounded-md border bg-white px-4 text-sm font-semibold">
              Save draft
            </button>
            <button type="submit" className="inline-flex h-10 items-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground">
              <Upload className="h-4 w-4" />
              Upload and classify
            </button>
          </div>
        </form>

        <aside className="space-y-4">
          <div className="panel p-5">
            <div className="flex items-start gap-3">
              <Info className="mt-0.5 h-5 w-5 text-primary" />
              <div>
                <h2 className="font-semibold">Document type matters</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Classifying files as tower information, pricing, RERA certificate, and similar types helps retrieval return the right answer faster.
                </p>
              </div>
            </div>
          </div>
          <div className="panel p-5">
            <h2 className="font-semibold">Suggested tags</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {["overview", "tower", "floor plan", "pricing", "legal", "rera", "amenities", "payment"].map((tag) => (
                <Badge key={tag}>{tag}</Badge>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}
