import { PageHeader } from "@/components/ui";
import { builders } from "@/lib/mock-data";

export function BuilderForm({ mode, builderId }: { mode: "add" | "edit"; builderId?: string }) {
  const builder = builders.find((item) => item.id === builderId);
  return (
    <>
      <PageHeader
        title={mode === "add" ? "Add builder" : "Edit builder"}
        description="Capture the builder identity that will be attached to future project documents."
      />
      <form className="panel max-w-3xl space-y-5 p-5">
        {/* TODO: Connect this form to a backend API or Server Action. */}
        <div className="grid gap-5 md:grid-cols-2">
          <label className="space-y-2">
            <span className="label">Builder name</span>
            <input className="field" defaultValue={builder?.name} placeholder="Urban Nest Developers" />
          </label>
          <label className="space-y-2">
            <span className="label">Contact person</span>
            <input className="field" defaultValue={builder?.contactPerson} placeholder="Sales manager name" />
          </label>
          <label className="space-y-2">
            <span className="label">Phone</span>
            <input className="field" defaultValue={builder?.phone} placeholder="+91 98765 43210" />
          </label>
          <label className="space-y-2">
            <span className="label">Email</span>
            <input className="field" defaultValue={builder?.email} placeholder="contact@builder.com" />
          </label>
        </div>
        <label className="space-y-2">
          <span className="label">Builder address</span>
          <textarea className="textarea-field" defaultValue={builder?.address} placeholder="Registered office address" />
        </label>
        <div className="flex justify-end gap-3">
          <button type="button" className="h-10 rounded-md border bg-white px-4 text-sm font-semibold">
            Cancel
          </button>
          <button type="submit" className="h-10 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground">
            Save builder
          </button>
        </div>
      </form>
    </>
  );
}
