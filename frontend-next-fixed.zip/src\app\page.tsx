import Link from "next/link";
import { Building2, Download, Eye, FileText, FolderKanban, Search, Trash2 } from "lucide-react";
import { Badge, ButtonLink, PageHeader, StatCard } from "@/components/ui";
import { builders, documents, getBuilder, getProject, projects } from "@/lib/mock-data";
import { formatFileSize } from "@/lib/utils";

export default function DashboardPage() {
  const recentDocuments = [...documents].sort((a, b) => b.uploadDate.localeCompare(a.uploadDate)).slice(0, 4);

  return (
    <>
      <PageHeader
        title="Dashboard"
        description="Manage builder, project, and document metadata before chatbot indexing."
        action={<ButtonLink href="/documents/upload">Upload document</ButtonLink>}
      />

      <section className="grid gap-4 md:grid-cols-3">
        <StatCard label="Total builders" value={builders.length} icon={Building2} />
        <StatCard label="Total projects" value={projects.length} icon={FolderKanban} tone="amber" />
        <StatCard label="Total documents" value={documents.length} icon={FileText} tone="slate" />
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="panel overflow-hidden">
          <div className="flex items-center justify-between border-b px-5 py-4">
            <div>
              <h2 className="font-semibold">Recently uploaded documents</h2>
              <p className="text-sm text-muted-foreground">Latest files prepared for searchable indexing.</p>
            </div>
            <Link href="/documents" className="text-sm font-semibold text-primary">
              View all
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead className="bg-secondary text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-5 py-3">Document</th>
                  <th className="px-5 py-3">Project</th>
                  <th className="px-5 py-3">Type</th>
                  <th className="px-5 py-3">Size</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {recentDocuments.map((document) => {
                  const project = getProject(document.projectId);
                  return (
                    <tr key={document.id} className="bg-white">
                      <td className="px-5 py-4">
                        <p className="font-medium">{document.title}</p>
                        <p className="text-xs text-muted-foreground">{document.fileName}</p>
                      </td>
                      <td className="px-5 py-4">{project?.name}</td>
                      <td className="px-5 py-4">
                        <Badge>{document.type}</Badge>
                      </td>
                      <td className="px-5 py-4">{formatFileSize(document.sizeMb)}</td>
                      <td className="px-5 py-4">
                        <div className="flex justify-end gap-2">
                          {[Eye, Download, Trash2].map((Icon, index) => (
                            <button
                              key={index}
                              className="rounded-md border p-2 text-muted-foreground transition hover:bg-secondary hover:text-foreground"
                              aria-label="Document action"
                            >
                              <Icon className="h-4 w-4" />
                            </button>
                          ))}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="panel p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-semibold">Quick search</h2>
              <p className="text-sm text-muted-foreground">Find files by builder, project, tags, or document type.</p>
            </div>
            <Search className="h-5 w-5 text-muted-foreground" />
          </div>
          <input className="field" placeholder="Try: Lavender floor plan, RERA, pricing..." />
          <div className="mt-4 space-y-3">
            {documents.slice(0, 3).map((document) => {
              const builder = getBuilder(document.builderId);
              const project = getProject(document.projectId);
              return (
                <Link
                  href={`/projects/${document.projectId}`}
                  key={document.id}
                  className="block rounded-md border bg-white p-3 transition hover:border-primary/40 hover:bg-primary/5"
                >
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-sm font-medium">{document.title}</p>
                    <Badge>{document.type}</Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {builder?.name} · {project?.name}
                  </p>
                </Link>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
}
