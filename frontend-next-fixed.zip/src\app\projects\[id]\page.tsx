import Link from "next/link";
import { Download, Eye, FileText, Search, Upload } from "lucide-react";
import { Badge, ButtonLink, PageHeader } from "@/components/ui";
import { documentTypes, getBuilder, getDocumentsForProject, getProject } from "@/lib/mock-data";
import { formatFileSize } from "@/lib/utils";

export default function ProjectDetailPage({ params }: { params: { id: string } }) {
  const project = getProject(params.id);

  if (!project) {
    return (
      <PageHeader
        title="Project not found"
        description="The requested project does not exist in the mock dataset."
      />
    );
  }

  const builder = getBuilder(project.builderId);
  const projectDocuments = getDocumentsForProject(project.id);

  return (
    <>
      <PageHeader
        title={project.name}
        description={`${builder?.name} · ${project.city}, ${project.state}`}
        action={
          <ButtonLink href="/documents/upload">
            <Upload className="h-4 w-4" />
            Upload document
          </ButtonLink>
        }
      />

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5">
          <h2 className="font-semibold">Builder information</h2>
          <div className="mt-4 space-y-2 text-sm text-muted-foreground">
            <p className="font-medium text-foreground">{builder?.name}</p>
            <p>{builder?.address}</p>
            <p>{builder?.contactPerson}</p>
            <p>{builder?.phone}</p>
            <p>{builder?.email}</p>
          </div>
        </div>
        <div className="panel p-5 lg:col-span-2">
          <h2 className="font-semibold">Project information</h2>
          <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
            <p>
              <span className="text-muted-foreground">Address</span>
              <br />
              {project.address}
            </p>
            <p>
              <span className="text-muted-foreground">RERA number</span>
              <br />
              <span className="font-mono text-xs">{project.reraNumber}</span>
            </p>
            <p>
              <span className="text-muted-foreground">Status</span>
              <br />
              <Badge>{project.status}</Badge>
            </p>
            <p>
              <span className="text-muted-foreground">Towers</span>
              <br />
              {project.towers.join(", ")}
            </p>
          </div>
        </div>
      </section>

      <section className="mt-6">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="text-lg font-semibold">Documents grouped by type</h2>
          <div className="relative sm:w-80">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input className="field pl-9" placeholder="Search within project..." />
          </div>
        </div>
        <div className="space-y-4">
          {documentTypes.map((type) => {
            const grouped = projectDocuments.filter((document) => document.type === type);
            if (grouped.length === 0) return null;

            return (
              <div key={type} className="panel overflow-hidden">
                <div className="border-b bg-secondary px-5 py-3">
                  <h3 className="font-semibold">{type}</h3>
                </div>
                <div className="divide-y">
                  {grouped.map((document) => (
                    <div key={document.id} className="flex flex-col gap-4 bg-white p-5 md:flex-row md:items-center md:justify-between">
                      <div>
                        <p className="font-medium">{document.title}</p>
                        <p className="mt-1 text-sm text-muted-foreground">{document.description}</p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          {document.tags.map((tag) => (
                            <Badge key={tag}>{tag}</Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">{formatFileSize(document.sizeMb)}</span>
                        <button className="rounded-md border p-2 text-muted-foreground hover:bg-secondary" aria-label="Preview">
                          <Eye className="h-4 w-4" />
                        </button>
                        <button className="rounded-md border p-2 text-muted-foreground hover:bg-secondary" aria-label="Download">
                          <Download className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {projectDocuments.length === 0 ? (
            <div className="panel p-8 text-center">
              <FileText className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-3 font-semibold">No documents yet</p>
              <Link href="/documents/upload" className="mt-1 inline-block text-sm font-semibold text-primary">
                Upload the first document
              </Link>
            </div>
          ) : null}
        </div>
      </section>
    </>
  );
}
