import { Edit, Mail, MapPin, Phone, Plus } from "lucide-react";
import { Badge, ButtonLink, PageHeader } from "@/components/ui";
import { builders, projects } from "@/lib/mock-data";

export default function BuildersPage() {
  return (
    <>
      <PageHeader
        title="Builders"
        description="Builder contact and address details used to classify every uploaded project document."
        action={
          <ButtonLink href="/builders/new">
            <Plus className="h-4 w-4" />
            Add builder
          </ButtonLink>
        }
      />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {builders.map((builder) => {
          const projectCount = projects.filter((project) => project.builderId === builder.id).length;
          return (
            <article key={builder.id} className="panel p-5">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-semibold">{builder.name}</h2>
                  <Badge className="mt-2">{projectCount} projects</Badge>
                </div>
                <ButtonLink href={`/builders/${builder.id}/edit`} variant="secondary">
                  <Edit className="h-4 w-4" />
                </ButtonLink>
              </div>
              <div className="space-y-3 text-sm text-muted-foreground">
                <p className="flex gap-2">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
                  {builder.address}
                </p>
                <p className="flex gap-2">
                  <Phone className="mt-0.5 h-4 w-4 shrink-0" />
                  {builder.contactPerson} · {builder.phone}
                </p>
                <p className="flex gap-2">
                  <Mail className="mt-0.5 h-4 w-4 shrink-0" />
                  {builder.email}
                </p>
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}
